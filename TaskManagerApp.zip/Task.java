
public class Task {
    private int id;
    private String title;
    private String description;
    private java.time.LocalDate dueDate;
    private String priority;

    public Task(int id, String title, String description, java.time.LocalDate dueDate, String priority) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.priority = priority;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public java.time.LocalDate getDueDate() { return dueDate; }
    public String getPriority() { return priority; }

    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setDueDate(java.time.LocalDate dueDate) { this.dueDate = dueDate; }
    public void setPriority(String priority) { this.priority = priority; }

    @Override
    public String toString() {
        return "ID: " + id + ", Title: " + title + ", Desc: " + description +
               ", Due: " + dueDate + ", Priority: " + priority;
    }
}
