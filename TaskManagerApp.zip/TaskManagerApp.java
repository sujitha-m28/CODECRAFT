
import java.time.LocalDate;
import java.util.*;

public class TaskManagerApp {
    private static List<Task> tasks = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    private static int idCounter = 1;

    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            notifyUpcomingTasks();
            System.out.println("\n=== Task Manager ===");
            System.out.println("1. Add Task");
            System.out.println("2. View Tasks by Due Date");
            System.out.println("3. View Tasks by Priority");
            System.out.println("4. Edit Task");
            System.out.println("5. Delete Task");
            System.out.println("6. Exit");
            System.out.print("Choose option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> addTask();
                case 2 -> viewByDueDate();
                case 3 -> viewByPriority();
                case 4 -> editTask();
                case 5 -> deleteTask();
                case 6 -> running = false;
                default -> System.out.println("Invalid option!");
            }
        }
    }

    private static void addTask() {
        System.out.print("Title: ");
        String title = scanner.nextLine();
        System.out.print("Description: ");
        String desc = scanner.nextLine();
        System.out.print("Due Date (YYYY-MM-DD): ");
        LocalDate dueDate = LocalDate.parse(scanner.nextLine());
        System.out.print("Priority (LOW/MEDIUM/HIGH): ");
        String priority = scanner.nextLine().toUpperCase();

        Task task = new Task(idCounter++, title, desc, dueDate, priority);
        tasks.add(task);
        System.out.println("Task added successfully.");
    }

    private static void viewByDueDate() {
        tasks.stream()
             .sorted(Comparator.comparing(Task::getDueDate))
             .forEach(System.out::println);
    }

    private static void viewByPriority() {
        tasks.stream()
             .sorted(Comparator.comparing(Task::getPriority))
             .forEach(System.out::println);
    }

    private static void editTask() {
        System.out.print("Enter Task ID to edit: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        for (Task t : tasks) {
            if (t.getId() == id) {
                System.out.print("New Title: ");
                t.setTitle(scanner.nextLine());
                System.out.print("New Description: ");
                t.setDescription(scanner.nextLine());
                System.out.print("New Due Date (YYYY-MM-DD): ");
                t.setDueDate(LocalDate.parse(scanner.nextLine()));
                System.out.print("New Priority (LOW/MEDIUM/HIGH): ");
                t.setPriority(scanner.nextLine().toUpperCase());
                System.out.println("Task updated.");
                return;
            }
        }
        System.out.println("Task ID not found.");
    }

    private static void deleteTask() {
        System.out.print("Enter Task ID to delete: ");
        int id = scanner.nextInt();
        tasks.removeIf(t -> t.getId() == id);
        System.out.println("Task deleted if ID existed.");
    }

    private static void notifyUpcomingTasks() {
        LocalDate today = LocalDate.now();
        tasks.stream()
             .filter(t -> !t.getDueDate().isBefore(today) && !t.getDueDate().isAfter(today.plusDays(2)))
             .forEach(t -> System.out.println("\u26A0 Task due soon: " + t));
    }
}
