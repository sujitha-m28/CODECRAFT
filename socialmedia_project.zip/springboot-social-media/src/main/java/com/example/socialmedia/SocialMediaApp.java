package com.example.socialmedia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialMediaApp {
    public static void main(String[] args) {
        SpringApplication.run(SocialMediaApp.class, args);
    }
}
